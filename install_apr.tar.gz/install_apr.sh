#!/usr/bin/env bash
#-*- coding: utf-8 -*-
#Author: Colinws
#Date:
#Desc:
#

sharepath='/tmp/colinws/'
aprpath="${sharepath}apr-1.5.2"
aprutilpath="${sharepath}apr-util-1.5.4"


echo "init ..."
if [ ! -d $sharepath ]
then
	mkdir -pv $sharepath
fi

cp ./apr-1.5.2.tar.gz $sharepath
cp ./apr-util-1.5.4.tar.gz $sharepath
## end init 


echo "install apr..."
cd ${aprpath}
./configure --prefix=/usr/local/apr  && make && make install 


echo "install apr-util ..."
cd ${aprutilpath}
./configure --prefix=/usr/local/apr-util --with-apr=/usr/local/apr  && make && make install 

echo "install tomcat native ..."
cd /usr/local/tomcat-${1}/bin/tomcat-native-1.1.33-src/jni/native/
./configure --with-apr=/usr/local/apr --with-java-home=/usr/java/jdk1.8.0_91 && make && make install 

echo "config profile"
sed -i '$aexport LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/apr/lib' /etc/profile
source /etc/profile
